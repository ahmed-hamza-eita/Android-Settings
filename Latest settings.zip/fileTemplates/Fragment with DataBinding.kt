#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "") package ${PACKAGE_NAME} ; #end



import android.util.Log
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import kotlinx.coroutines.launch

class ${NameFragment}: BaseFragment<${FragmentNameBinding}, ${ViewModel}>() {


    override val viewModel: ${ViewModel} by viewModels {
        RegisterViewModelFactory(requireContext())
    }

    override fun getLayoutResId(): Int = //R.layout.fragment_login


    override fun init() {
      //  initListeners()
      //  initViewModel()
    }


     

    

    companion object {
        private const val TAG = "RegisterFragment"

    }
}