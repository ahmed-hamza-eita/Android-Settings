#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "") package ${PACKAGE_NAME} ; #end

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.viewbinding.ViewBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ${NameFragment} : BindingFragment<${FragmentNameBinding}>() {
    override val bindingInflater: (LayoutInflater) -> ViewBinding
        get() = ${FragmentNameBinding}::inflate

    //private val vm: LoginViewModel by viewModels()
    
     
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            lifecycleOwner = viewLifecycleOwner
            viewmodel = registerViewModel
        }
    }

    
    
    }