#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "") package ${PACKAGE_NAME} ; #end


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup


class ${FRAGMENT_NAME} :  Fragment() {

    private var _binding: ${BINDING}? = null
    private val binding get() = _binding!!

    

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = ${BINDING}.inflate(inflater, container, false)
        binding.apply {
            lifecycleOwner = viewLifecycleOwner
            viewmodel = viewmodel

        }
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val TAG = ${FRAGMENT_NAME}
    }

}