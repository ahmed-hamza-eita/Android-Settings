#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "") package ${PACKAGE_NAME} ; #end

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
 

 class ${FRAGMENT_NAME} : BaseFragment() {

    private var _binding: ${BINDING}? = null
    private val binding get() = _binding!!

   


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout. , container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = ${BINDING}.bind(view)



    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}