#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "") package ${PACKAGE_NAME} ; #end

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
   


class ${ADAPTER_NAME}  : RecyclerView.Adapter<${ADAPTER_NAME}.Holder>() {
    inner class Holder constructor(val binding: ${BINDING}) :
        RecyclerView.ViewHolder(binding.root) {
        
    }

    private val differCallback = object : DiffUtil.ItemCallback<${MODEL}>() {
        override fun areItemsTheSame(oldItem: ${MODEL}, newItem: ${MODEL}): Boolean {
            return oldItem.url == newItem.url
        }

        override fun areContentsTheSame(oldItem: ${MODEL}, newItem: ${MODEL}): Boolean {
            return oldItem == newItem
        }
    }
    val differ = AsyncListDiffer(this, differCallback)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val binding = ${BINDING}.inflate(
            LayoutInflater.from(parent.context),
            parent, false
        )
        return Holder(binding)
    }

    override fun getItemCount(): Int {
        return differ.currentList.size
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val data = differ.currentList[position]
        holder.binding.apply {
            //data.text=Model.name
            holder.itemView.setOnClickListener {
                onItemClickListener?.let{
                    it(data)
                }
            }
        }
    }


    private var onItemClickListener: ((${MODEL}) -> Unit)? = null
    fun setOnItemClickListener(listener: ((${MODEL}) -> Unit)) {
        onItemClickListener = listener
    }

}
