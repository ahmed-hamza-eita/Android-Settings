#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "") package ${PACKAGE_NAME} ; #end

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
 

class ${ADAPTER_NAME} : RecyclerView.Adapter<${ADAPTER_NAME}.Holder>() {

    var list: ArrayList<>? = null
    var onItemClick: OnItemClick? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val binding = ${iTEM_BINDING}.inflate(
            LayoutInflater.from(parent.context),
            parent, false
        )
        return Holder(binding)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val data = list?.get(position)
        holder.binding.apply {

        }
    }

    override fun getItemCount(): Int {
        return list?.size ?: 0
    }

    inner class Holder constructor(val binding: ${iTEM_BINDING}) :
        RecyclerView.ViewHolder(binding.root) {
        init {
           itemView.setOnClickListener {
               onItemClick?.onItemClick(list?.get(layoutPosition)?.id!!)
           }
        }
    }

    interface OnItemClick {
        fun onItemClick(id: Int)
    }
}